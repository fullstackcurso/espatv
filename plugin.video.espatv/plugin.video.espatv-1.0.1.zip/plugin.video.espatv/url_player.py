# -*- coding: utf-8 -*-
# EspaTV — Copyright (C) 2024-2026 RubénSDFA1labernt (github.com/espakodi)
# Licencia: GPL-2.0-or-later — Consulta el archivo LICENSE para mas detalles.
"""
Reproductor de URLs Externas para EspaTV

Permite al usuario pegar una URL de vídeo y reproducirla en Kodi.

Detección inteligente:
  - Dailymotion (dailymotion.com / dai.ly)   -> dm_gujal
  - YouTube     (youtube.com / youtu.be)      -> plugin.video.youtube
  - Streams     (.m3u8 / .mp4 / .mpd / etc.)  -> reproducción directa
  - Torrents    (magnet: / .torrent)           -> plugin.video.elementum
  - AceStream   (acestream://)                -> script.module.horus / program.plexus
  - Otras webs                                -> SendToKodi / yt-dlp
"""
# noinspection PyUnresolvedReferences
import sys
import os
import json
import time
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import ytdlp_resolver

_ADDON_ID = "plugin.video.espatv"
_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

_STREAM_EXTENSIONS = {
    ".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".flv",
    ".mov", ".wmv", ".webm", ".mpd", ".m3u",
}

_ACESTREAM_RE = re.compile(r"^acestream://[0-9a-fA-F]{40}$")


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), "url_history.json")


def _bookmarks_path():
    return os.path.join(_get_profile(), "url_bookmarks.json")


def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
    except IOError:
        pass


def parse_url_with_headers(raw_url):
    """Separa URL y headers en formato pipe.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", ...})
    """
    if not raw_url:
        return "", {}
    raw_url = raw_url.strip()
    if "|" not in raw_url:
        return raw_url, {}

    parts = raw_url.split("|", 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()
    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = value
    return url, headers


def is_direct_stream(url):
    """Determina si la URL apunta a un stream reproducible directamente."""
    try:
        parsed = urllib.parse.urlparse(url)
        _, ext = os.path.splitext(parsed.path.lower())
        return ext in _STREAM_EXTENSIONS
    except Exception:
        return False


def build_kodi_url(url, headers=None):
    """Reconstruye URL con headers en formato pipe de Kodi."""
    if not headers:
        return url
    parts = ["{0}={1}".format(k, v) for k, v in headers.items()]
    return url + "|" + "&".join(parts)


def detect_dailymotion_id(url):
    """Extrae el ID de un vídeo de Dailymotion o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host.endswith("dailymotion.com"):
            match = re.match(r"/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
            match = re.match(r"/embed/video/([a-zA-Z0-9]+)", parsed.path)
            if match:
                return match.group(1)
        elif host == "dai.ly":
            vid = parsed.path.strip("/")
            if vid:
                return vid.split("_")[0].split("?")[0]
    except Exception:
        pass
    return None


def detect_youtube_id(url):
    """Extrae el ID de un vídeo de YouTube o devuelve None."""
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
        host = (parsed.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]

        if host in ("youtube.com", "m.youtube.com"):
            if "/watch" in parsed.path:
                params = urllib.parse.parse_qs(parsed.query)
                vid_list = params.get("v", [])
                if vid_list:
                    return vid_list[0]
            elif "/shorts/" in parsed.path:
                match = re.match(r"/shorts/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
            elif "/live/" in parsed.path:
                match = re.match(r"/live/([a-zA-Z0-9_-]+)", parsed.path)
                if match:
                    return match.group(1)
        elif host == "youtu.be":
            vid = parsed.path.strip("/")
            if vid:
                return vid
    except Exception:
        pass
    return None


def detect_url_type(raw_url):
    """Clasifica una URL y devuelve (tipo, id_o_url).
    Tipos: 'dailymotion', 'youtube', 'torrent', 'acestream',
           'direct_stream', 'web_page'
    """
    url, _ = parse_url_with_headers(raw_url)

    # Magnet links y ficheros .torrent
    if url.startswith("magnet:"):
        return "torrent", url
    try:
        parsed_path = urllib.parse.urlparse(url).path.lower()
        if parsed_path.endswith(".torrent"):
            return "torrent", url
    except Exception:
        pass

    # AceStream
    if _ACESTREAM_RE.match(url):
        return "acestream", url

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return "dailymotion", dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return "youtube", yt_id

    if is_direct_stream(url):
        return "direct_stream", raw_url

    return "web_page", url

_YT_RE = re.compile(
    r"(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)"
    r"([A-Za-z0-9_-]{11})"
)
_DM_RE = re.compile(
    r"(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)"
)
_VIMEO_RE = re.compile(r"vimeo\.com/(\d+)")
_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_THUMB_TIMEOUT = 3


def _auto_thumb(url):
    """Devuelve la URL de miniatura para la URL dada, o cadena vacia.

    Soporta YouTube, Dailymotion (sin HTTP), Vimeo (oEmbed) y webs
    genericas (og:image). En caso de error devuelve cadena vacia.
    """
    if not url:
        return ""
    # YouTube — sin peticion HTTP
    m = _YT_RE.search(url)
    if m:
        return "https://img.youtube.com/vi/{0}/hqdefault.jpg".format(m.group(1))
    # Dailymotion — sin peticion HTTP
    m = _DM_RE.search(url)
    if m:
        return "https://www.dailymotion.com/thumbnail/video/{0}".format(m.group(1))
    # Vimeo — oEmbed API (sin autenticacion)
    m = _VIMEO_RE.search(url)
    if m:
        return _vimeo_thumb(url)
    # Webs genericas — intentar og:image
    if url.startswith("http"):
        return _og_thumb(url)
    return ""


def _vimeo_thumb(url):
    """Obtiene miniatura de Vimeo via oEmbed."""
    try:
        import requests
        r = requests.get(
            "https://vimeo.com/api/oembed.json",
            params={"url": url, "width": 480},
            timeout=_THUMB_TIMEOUT,
        )
        if r.status_code == 200:
            return r.json().get("thumbnail_url", "")
    except Exception:
        pass
    return ""


def _og_thumb(url):
    """Extrae la meta tag og:image del HTML de una pagina web."""
    try:
        import requests
        r = requests.get(
            url,
            timeout=_THUMB_TIMEOUT,
            headers={"User-Agent": "Mozilla/5.0"},
            stream=True,
        )
        try:
            if r.status_code != 200:
                return ""
            chunk = r.raw.read(8192).decode("utf-8", errors="ignore")
            m = _OG_RE.search(chunk)
            if m:
                return m.group(1) or m.group(2) or ""
        finally:
            r.close()
    except Exception:
        pass
    return ""


def _auto_label(url):
    """Genera un titulo legible para la URL dada.

    YouTube/DM/Vimeo: titulo real via oEmbed (sin autenticacion).
    Otras URLs: nombre derivado del path.
    """
    if not url:
        return ""
    try:
        import requests
        # YouTube
        m = _YT_RE.search(url)
        if m:
            r = requests.get(
                "https://www.youtube.com/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Dailymotion
        m = _DM_RE.search(url)
        if m:
            r = requests.get(
                "https://www.dailymotion.com/services/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Vimeo
        m = _VIMEO_RE.search(url)
        if m:
            r = requests.get(
                "https://vimeo.com/api/oembed.json",
                params={"url": url},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
    except Exception:
        pass
    # Fallback: limpiar path de la URL
    try:
        from urllib.parse import urlparse
        path = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1]
        if "." in path:
            path = path.rsplit(".", 1)[0]
        name = path.replace("-", " ").replace("_", " ")
        return name[:80] if name else ""
    except Exception:
        return ""


def _add_to_history(raw_url, label=None, thumb=None):
    history = _load_json(_history_path())
    # Reutilizar thumb y label de la entrada existente
    if not thumb or not label:
        for h in history:
            if h.get("url") == raw_url:
                if not thumb and h.get("thumb"):
                    thumb = h["thumb"]
                if not label and h.get("label") and h["label"] != raw_url:
                    label = h["label"]
                break
    history = [h for h in history if h.get("url") != raw_url]
    if not thumb:
        thumb = _auto_thumb(raw_url)
    if not label or label == raw_url:
        fetched = _auto_label(raw_url)
        label = fetched or raw_url
    entry = {
        "url": raw_url,
        "label": label,
        "date": time.strftime("%d/%m/%Y %H:%M"),
        "timestamp": int(time.time()),
    }
    if thumb:
        entry["thumb"] = thumb
    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    _save_json(_history_path(), [])


def _remove_from_history(url):
    history = _get_history()
    history = [h for h in history if h.get("url") != url]
    _save_json(_history_path(), history)


def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    bookmarks = _get_bookmarks()
    if any(b.get("url") == url for b in bookmarks):
        return False
    thumb = _auto_thumb(url)
    entry = {
        "name": name,
        "url": url,
        "date": time.strftime("%d/%m/%Y %H:%M"),
    }
    if thumb:
        entry["thumb"] = thumb
    bookmarks.append(entry)
    bookmarks = bookmarks[:MAX_BOOKMARKS]
    _save_json(_bookmarks_path(), bookmarks)
    return True


def _remove_bookmark(url):
    bookmarks = _get_bookmarks()
    new_bookmarks = [b for b in bookmarks if b.get("url") != url]
    _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    bookmarks = _get_bookmarks()
    changed = False
    for b in bookmarks:
        if b.get("url") == url:
            b["name"] = new_name
            changed = True
            break
    if changed:
        _save_json(_bookmarks_path(), bookmarks)
    return changed


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    """Menú principal de Abrir URL."""
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(
        label="[COLOR limegreen][B]Pegar URL de vídeo[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultAddSource.png"})
    li.setInfo("video", {
        "plot": (
            "Pega una URL de vídeo para reproducirla.\n\n"
            "URLs soportadas:\n"
            "  \u2022 Dailymotion: dailymotion.com/video/xxx\n"
            "  \u2022 YouTube: youtube.com/watch?v=xxx\n"
            "  \u2022 Stream directo: .m3u8, .mp4, .mkv, .mpd\n"
            "  \u2022 Con headers: URL|User-Agent=xxx&Referer=yyy\n"
            "  \u2022 Otras webs: resolución automática"
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_input"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label="[COLOR lightsalmon][B]Enviar URL desde movil/PC[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultNetwork.png"})
    li.setInfo("video", {
        "plot": (
            "Abre un servidor temporal en la red local.\n\n"
            "Desde el navegador de tu movil o PC, "
            "podras pegar la URL sin necesidad de escribirla "
            "con el mando.\n\n"
            "Ideal para dispositivos sin teclado.\n\n"
            "Tambien disponible como addon independiente más completo:\n"
            "  \u2022 LoioLink - Enviar URLs y texto\n"
            "  \u2022 LoioMote - Control remoto web\n"
            "Ambos con API para integrar en otros addons."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_remote"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label="[COLOR mediumpurple][B]Escanear v\u00eddeos de una web[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    li.setInfo("video", {
        "plot": (
            "Pega la URL de cualquier p\u00e1gina web y el addon "
            "detectar\u00e1 todos los v\u00eddeos disponibles.\n\n"
            "Muestra t\u00edtulo, duraci\u00f3n y tama\u00f1o de cada uno.\n\n"
            "En PC usa yt-dlp (m\u00e1s completo).\n"
            "En Android usa an\u00e1lisis HTML."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_scan"), listitem=li, isFolder=False
    )

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(
            label="[COLOR cyan]Historial de URLs ({0})[/COLOR]".format(len(history))
        )
        li.setArt({"icon": "DefaultRecentlyAddedMovies.png"})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_history"), listitem=li, isFolder=True
        )

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR khaki]Marcadores ({0})[/COLOR]".format(len(bookmarks))
        )
        li.setArt({"icon": "DefaultSets.png"})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_bookmarks"), listitem=li, isFolder=True
        )

    xbmcplugin.endOfDirectory(h)


def _resolve_and_play(raw_url):
    """Detecta tipo de URL y reproduce con el método adecuado."""
    url_type, value = detect_url_type(raw_url)

    if url_type == "dailymotion":
        xbmcgui.Dialog().notification(
            "EspaTV", "Dailymotion: " + value,
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        played = False

        # yt-dlp como primera opción en PC (mejor compatibilidad CDN)
        if ytdlp_resolver.is_available():
            dm_url = "https://www.dailymotion.com/video/" + value
            stream_url = ytdlp_resolver.resolve(dm_url)
            if stream_url:
                li = xbmcgui.ListItem(path=stream_url)
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)
                xbmc.Player().play(stream_url, li)
                played = True

        if not played:
            try:
                import dm_gujal
                result = dm_gujal.play_dm_extreme(value)
                if result and result[0]:
                    final_url, subs, mime = result
                    li = xbmcgui.ListItem(path=final_url)
                    if mime:
                        li.setMimeType(mime)
                    if subs and isinstance(subs, list):
                        li.setSubtitles(subs)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(final_url, li)
                    played = True
            except Exception as e:
                xbmc.log(
                    "[EspaTV/url_player] dm_gujal error: " + str(e),
                    xbmc.LOGWARNING,
                )

        if not played:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "No se pudo resolver el vídeo de Dailymotion.",
            )

    elif url_type == "youtube":
        played = False
        yt_web = "https://www.youtube.com/watch?v=" + value

        # Método 1: addon plugin.video.youtube (necesita API key)
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.youtube)"):
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo en YouTube...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = "plugin://plugin.video.youtube/play/?video_id=" + value
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
            played = True

        # Método 2: yt-dlp (solo en PC, sin addon ni API key)
        if not played and ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stream_url = ytdlp_resolver.resolve(yt_web)
            if stream_url:
                li = xbmcgui.ListItem(path=stream_url)
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)
                xbmc.Player().play(stream_url, li)
                played = True

        if not played:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "No se pudo reproducir el video de YouTube.\n\n"
                "Opciones:\n"
                "  \u2022 Instala plugin.video.youtube\n"
                "  \u2022 Instala yt-dlp (pip install yt-dlp)",
            )

    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        kodi_url = build_kodi_url(url, headers)
        li = xbmcgui.ListItem(path=kodi_url)
        if ".mpd" in url.lower():
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        elif ".m3u8" in url.lower():
            li.setMimeType("application/x-mpegURL")
        if headers:
            header_str = "&".join("{0}={1}".format(k, v) for k, v in headers.items())
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
        xbmc.Player().play(kodi_url, li)

    elif url_type == "torrent":
        has_elementum = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.elementum)"
        )
        if has_elementum:
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo torrent en Elementum...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            elem_url = (
                "plugin://plugin.video.elementum/play?"
                + urllib.parse.urlencode({"uri": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Para reproducir torrents necesitas instalar "
                "el addon Elementum.\n\n"
                "Descargalo desde su repositorio oficial en GitHub.",
            )

    elif url_type == "acestream":
        # Extraer hash del content ID
        ace_hash = value.replace("acestream://", "")
        has_horus = xbmc.getCondVisibility(
            "System.HasAddon(script.module.horus)"
        )
        has_plexus = xbmc.getCondVisibility(
            "System.HasAddon(program.plexus)"
        )
        if has_horus:
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo AceStream con Horus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            horus_url = (
                "plugin://script.module.horus/?"
                + urllib.parse.urlencode({"action": "play", "id": ace_hash})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(horus_url))
        elif has_plexus:
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo AceStream con Plexus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            plexus_url = (
                "plugin://program.plexus/?"
                + urllib.parse.urlencode({
                    "url": value, "mode": "1", "name": "AceStream"
                })
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(plexus_url))
        else:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Para reproducir enlaces AceStream necesitas "
                "instalar uno de estos addons:\n\n"
                "  \u2022 Horus (script.module.horus)  [recomendado]\n"
                "  \u2022 Plexus (program.plexus)\n\n"
                "Ademas necesitas el motor AceStream instalado "
                "en el dispositivo.",
            )

    elif url_type == "web_page":
        has_stk = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.sendtokodi)"
        )
        has_yt = xbmc.getCondVisibility(
            "System.HasAddon(plugin.video.youtube)"
        )
        if has_stk:
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con SendToKodi...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stk_url = (
                "plugin://plugin.video.sendtokodi/?"
                + urllib.parse.urlencode({"url": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(stk_url))
        elif has_yt:
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con YouTube...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = (
                "plugin://plugin.video.youtube/uri2addon/?uri="
                + urllib.parse.quote(value)
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        elif ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stream_url = ytdlp_resolver.resolve(value)
            if stream_url:
                li = xbmcgui.ListItem(path=stream_url)
                li.setProperty("IsPlayable", "true")
                li.setContentLookup(False)
                xbmc.Player().play(stream_url, li)
            else:
                xbmcgui.Dialog().ok(
                    "EspaTV",
                    "yt-dlp no pudo resolver esta URL.\n\n"
                    "Puedes instalar addons adicionales:\n"
                    "  \u2022 plugin.video.sendtokodi\n"
                    "  \u2022 plugin.video.youtube\n\n"
                    "O pega directamente la URL del stream.",
                )
        else:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "No se puede resolver esta URL.\n\n"
                "Instala uno de estos addons:\n"
                "  \u2022 plugin.video.sendtokodi (recomendado)\n"
                "  \u2022 plugin.video.youtube\n\n"
                "O pega directamente la URL del stream.",
            )


def url_input():
    """Teclado para pegar una URL y reproducirla."""
    kb = xbmc.Keyboard("", "Pegar URL (Dailymotion, YouTube, stream...)")
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    valid_schemes = ("http://", "https://", "rtmp://", "rtsp://",
                     "magnet:?", "acestream://")
    if not raw.startswith(valid_schemes):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "La URL no parece v\u00e1lida.\n\n"
            "Esquemas soportados: http, https, rtmp, rtsp, magnet, acestream",
        )
        return

    _add_to_history(raw)

    url_type, _ = detect_url_type(raw)
    type_labels = {
        "dailymotion": "Dailymotion",
        "youtube": "YouTube",
        "torrent": "Torrent",
        "acestream": "AceStream",
        "direct_stream": "Stream directo",
        "web_page": "P\u00e1gina web",
    }
    detected = type_labels.get(url_type, "Desconocido")
    url_display = raw[:50] + "..." if len(raw) > 50 else raw

    opts = [
        "Reproducir ahora ({0})".format(detected),
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador",
    ]
    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification(
                    "EspaTV", "Marcador guardado",
                    xbmcgui.NOTIFICATION_INFO,
                )
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(
                    "EspaTV", "Ya existe este marcador",
                    xbmcgui.NOTIFICATION_INFO,
                )


def url_history_menu():
    """Historial de URLs reproducidas."""
    h = int(sys.argv[1])
    history = _get_history()

    if not history:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay URLs en el historial[/COLOR]"
        )
        li.setArt({"icon": "DefaultIconInfo.png"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(
        label="[COLOR red][B]Borrar todo el historial de URLs[/B][/COLOR]"
    )
    li.setArt({"icon": "DefaultIconError.png"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_url = entry.get("url", "")
        label = entry.get("label", raw_url)
        date = entry.get("date", "")

        display = label[:80] + "..." if len(label) > 80 else label
        thumb = entry.get("thumb", "")
        li = xbmcgui.ListItem(label=display)
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": "URL: {0}\n\nFecha: {1}".format(raw_url, date)})

        cm = [
            (
                "Guardar como marcador",
                "RunPlugin({0})".format(
                    _u(action="url_bookmark_save_from_history", url=raw_url)
                ),
            ),
            (
                "Eliminar del historial",
                "RunPlugin({0})".format(
                    _u(action="url_history_remove", url=raw_url)
                ),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=raw_url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    """Marcadores de URLs guardados."""
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()

    if not bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay marcadores guardados[/COLOR]"
        )
        li.setArt({"icon": "DefaultIconInfo.png"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get("url", "")
        name = bm.get("name", url)
        date = bm.get("date", "")

        li = xbmcgui.ListItem(label=name)
        thumb = bm.get("thumb", "")
        li.setArt({
            "icon": thumb or "DefaultVideo.png",
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": "URL: {0}\n\nGuardado: {1}".format(url, date)})

        cm = [
            (
                "Renombrar",
                "RunPlugin({0})".format(_u(action="url_bookmark_rename", url=url)),
            ),
            (
                "Eliminar marcador",
                "RunPlugin({0})".format(_u(action="url_bookmark_delete", url=url)),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard("", "Nombre para el marcador")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification(
                "EspaTV", "Marcador guardado", xbmcgui.NOTIFICATION_INFO
            )
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification(
                "EspaTV", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO
            )


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ""
    for b in bookmarks:
        if b.get("url") == url:
            current_name = b.get("name", "")
            break

    kb = xbmc.Keyboard(current_name, "Nuevo nombre")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification(
            "EspaTV", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO
        )
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("EspaTV", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def play_url_action(raw_url):
    """Reproduce una URL registr\u00e1ndola en el historial."""
    if not raw_url:
        return
    import threading
    threading.Thread(target=_add_to_history, args=(raw_url,), daemon=True).start()
    _resolve_and_play(raw_url)


def scan_videos_dialog():
    """Escanea una web en busca de v\u00eddeos y permite reproducirlos."""
    kb = xbmc.Keyboard("", "URL de la p\u00e1gina a escanear")
    kb.doModal()
    if not kb.isConfirmed():
        return

    url = kb.getText().strip()
    if not url:
        return

    if not url.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "La URL debe empezar por http:// o https://",
        )
        return

    pdp = xbmcgui.DialogProgress()
    pdp.create("Escaneando v\u00eddeos", "Analizando {0}...".format(url[:60]))

    try:
        videos = _scan_with_best_engine(url)
    except Exception as exc:
        xbmc.log(
            "[EspaTV] Error escaneando {0}: {1}".format(url[:60], exc),
            xbmc.LOGWARNING,
        )
        videos = []
    finally:
        pdp.close()

    if not videos:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No se encontraron v\u00eddeos en esta p\u00e1gina.\n\n"
            "Prueba con otra URL o pega directamente \n"
            "la URL del v\u00eddeo.",
        )
        return

    import html_scanner

    labels = []
    for v in videos:
        parts = [v.get("title") or v.get("url", "")[:60]]
        dur = v.get("duration")
        if dur:
            parts.append(html_scanner.format_duration(dur))
        size = v.get("filesize")
        if size:
            parts.append(html_scanner.format_size(size))
        ext = v.get("ext", "")
        if ext:
            parts.append(ext.upper())
        labels.append(" \u2014 ".join(parts))

    sel = xbmcgui.Dialog().select(
        "V\u00eddeos encontrados ({0})".format(len(videos)), labels
    )
    if sel < 0:
        return

    chosen = videos[sel]
    chosen_url = chosen.get("url", "")
    if chosen_url:
        _add_to_history(chosen_url, label=chosen.get("title"))
        _resolve_and_play(chosen_url)


def _scan_with_best_engine(url):
    """Elige el motor adecuado seg\u00fan la plataforma y escanea."""
    # En PC, usar yt-dlp si est\u00e1 disponible
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)
        if results:
            return results

    # Fallback universal: esc\u00e1ner HTML
    import html_scanner
    return html_scanner.scan_page(url)
